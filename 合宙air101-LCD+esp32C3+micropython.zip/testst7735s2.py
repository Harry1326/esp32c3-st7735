from st77352 import TFT
from machine import SPI,Pin
import time
#hardware SPI, HSPI
spi=SPI(1,baudrate=40000000, polarity=0, phase=0, sck=Pin(2), mosi=Pin(3))
tft=TFT(spi,6,10,7)# dc, rst, cs   #6,10,7 aDC, aReset, aCS
tft.rgb(False)
tft.init_7735(tft.REDTAB80x160)
while 1:
    time.sleep(1)
    tft.fill(TFT.WHITE)
    time.sleep(1)
    tft.fill(TFT.RED)
    time.sleep(1)
    tft.fill(TFT.GREEN)
    time.sleep(1)
    tft.fill(TFT.BLUE)